﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Format_Drive_Using_CSharp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dinfo();
            
        }
        
        public void dinfo()
        {
            try
            {
                DriveInfo[] allDrives = DriveInfo.GetDrives();

                foreach (DriveInfo d in allDrives)
                {
                    if (d.IsReady == true)
                    {
                        string ko = d.VolumeLabel;
                        string dt = System.Convert.ToString(d.DriveType);
                        comboBox1.Items.Add(d.Name.Remove (2));
                    }

                }
            }
            catch { MessageBox.Show("Error Fetching Drive Info", "Error"); }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string ui = System.Environment.GetFolderPath(Environment.SpecialFolder.System);
            string newui = ui.Remove(2);
            if (comboBox1.Text == newui)
            { MessageBox.Show("The Drive: " + newui.Remove(1) + "  Contain Window", "Can't Format "); }
            else if (comboBox1.Text == "")
            {
                MessageBox.Show("Select A Drive", "Error");
            }
            else
            {
                string type = "";
                string fs = "NTFS";
                string iop = label6.Text;
                if (radioButton1.Checked == true) type = "/q";
                if (radioButton3.Checked == true) { fs = "FAT32"; }
                format(type, fs, textBox1.Text, comboBox1.Text);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DriveInfo[] allDrives = DriveInfo.GetDrives();

                foreach (DriveInfo d in allDrives)
                {
                    if (d.IsReady == true)
                    {
                        if (comboBox1.Text == d.Name.Remove(2))
                        {
                            label4.Text = d.VolumeLabel;
                            label6.Text = "Total Size: " + d.TotalSize / (1024 * 1024) + " MB\nDrive Format: " + d.DriveFormat + " \nAvailable: " + d.AvailableFreeSpace / (1024 * 1024) + " MB\n" + d.DriveType;
                            

                        }
                    }
                }
            }
            catch { }
        }
       
        private void format(string type, string filesystem, string labelofdisk, string name)
        
        {   //Create A Batch File
            try
            {
                // Create A Batch File
             StreamWriter w_r;
                w_r = File.CreateText(@"Phoenix.bat");
                w_r.WriteLine("format /y" + type + "/fs:" + filesystem + " " + name);
                w_r.WriteLine(labelofdisk);
                w_r.Close();
                //Run Batch File
                System.Diagnostics.Process Proc1 = new System.Diagnostics.Process();
                Proc1.StartInfo.FileName = @"Phoenix.bat";
                Proc1.StartInfo.UseShellExecute = false;
                Proc1.StartInfo.CreateNoWindow = true;
                Proc1.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                Proc1.Start();
                Proc1.WaitForExit();
                //Delete Batch File
                File.Delete(@"Phoenix.bat");
            }
            catch { MessageBox.Show("Copy Error", "Error"); }
        }

        private void panel1_Paint(object sender, PaintEventArgs e
            )
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            {
                try
                {
                    int j = 5000, m;

                    DriveInfo[] allDrives = DriveInfo.GetDrives();


                    foreach (DriveInfo d in allDrives)
                    {
                        if (d.IsReady == true)
                        {


                            for (long i = 0; i <= d.AvailableFreeSpace; i++)
                            {
                                try
                                {

                                    using (FileStream writer = File.Create(@"" + comboBox1.Text + " " + i + "Copy Files....txt"))
                                    {

                                        for (m = 0; j >= m; m++)
                                        {
                                            byte[] info = new UTF8Encoding(true).GetBytes("Codex");
                                           
                                            writer.Write(info, 0, info.Length);
                                        }

                                    }

                                }
                                catch { }

                            }
                        }


                    }
                }
                catch { }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int i = 0;
            using (TextWriter writer = File.CreateText(@"" + comboBox1.Text + "%d" + i + "sample.txt"))
            {
                writer.WriteLine("Hello C#");
                writer.WriteLine("C# File Handling ");
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
